#include "drlcd.h"

DR_lcd DR_LCD;